package com.wans.hajatan

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val bg = Color.parseColor("#101418")
    private val card = Color.parseColor("#1D242D")
    private val yellow = Color.parseColor("#FFC933")
    private val muted = Color.parseColor("#D5DCE5")

    private var events = JSONArray()
    private var guests = JSONArray()
    private var current: String? = null
    private var query = ""
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout

    private val prefs by lazy { getSharedPreferences("hajatan", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rupiah(v: Long) = "Rp " + NumberFormat.getNumberInstance(Locale("id", "ID")).format(v)
    private fun JSONArray.items() = (0 until length()).map { getJSONObject(it) }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        events = JSONArray(prefs.getString("events", "[]"))
        guests = JSONArray(prefs.getString("guests", "[]"))
        current = state?.getString("current")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            fitsSystemWindows = true
        }
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (current != null) { current = null; query = ""; show() } else finish()
            }
        })
        show()
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putString("current", current)
    }

    private fun save() {
        prefs.edit().putString("events", events.toString()).putString("guests", guests.toString()).apply()
    }

    private fun text(s: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
    }

    private fun box(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(14).toFloat() }

    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f
        setTextColor(Color.BLACK); background = box(yellow)
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.add(v: View, top: Int = 8) {
        addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }

    private fun show() {
        root.removeAllViews()
        val ev = events.items().find { it.getString("id") == current }
        if (ev == null) current = null
        root.add(text(ev?.getString("n") ?: "Catatan Hajatan", 24f, yellow))
        if (ev != null) root.add(EditText(this).apply {
            hint = "Cari nama atau alamat"; setSingleLine()
            setTextColor(Color.WHITE); setHintTextColor(muted); setText(query)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s.toString(); fill() }
            })
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.add(button(if (ev == null) "+ Acara baru" else "+ Tambah tamu") {
            if (ev == null) eventForm() else guestForm(null)
        })
        fill()
    }

    private fun row(title: String, sub: String, onClick: () -> Unit, onHold: () -> Unit) {
        list.add(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(text(title, 18f))
            addView(text(sub, 15f, muted))
            setOnClickListener { onClick() }
            setOnLongClickListener { onHold(); true }
        })
    }

    private fun fill() {
        list.removeAllViews()
        val id = current
        if (id == null) {
            if (events.length() == 0) list.add(text("Belum ada acara. Tekan Acara baru.", 16f, muted), 24)
            for (e in events.items()) {
                val eid = e.getString("id")
                val count = guests.items().count { it.getString("e") == eid }
                row(e.getString("n"), "$count tamu", { current = eid; show() }) {
                    confirm("Hapus acara \"${e.getString("n")}\" beserta $count tamu?") {
                        events = JSONArray(events.items().filter { it.getString("id") != eid })
                        guests = JSONArray(guests.items().filter { it.getString("e") != eid })
                        save(); fill()
                    }
                }
            }
            return
        }
        val mine = guests.items().filter { it.getString("e") == id }
        list.add(text("${mine.size} tamu, total ${rupiah(mine.sumOf { it.optLong("m") })}", 16f, yellow))
        mine.filter { (it.getString("n") + " " + it.optString("a")).contains(query, true) }
            .sortedBy { it.getString("n").lowercase() }
            .forEach { g ->
                row(g.getString("n"), "${g.optString("a")}\n${rupiah(g.optLong("m"))}", { guestForm(g) }) {
                    confirm("Hapus ${g.getString("n")}?") {
                        guests = JSONArray(guests.items().filter { it.getString("id") != g.getString("id") })
                        save(); fill()
                    }
                }
            }
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Hapus") { _, _ -> yes() }.setNegativeButton("Batal", null).show()
    }

    private fun form(title: String, fields: List<EditText>, onSave: () -> Boolean) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
            fields.forEach { add(it) }
        }
        val d = AlertDialog.Builder(this).setTitle(title).setView(col)
            .setPositiveButton("Simpan", null).setNegativeButton("Batal", null).show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { if (onSave()) d.dismiss() }
    }

    private fun input(h: String, v: String = "") = EditText(this).apply { hint = h; setText(v) }

    private fun eventForm() {
        val name = input("Nama acara")
        form("Acara baru", listOf(name)) {
            val n = name.text.toString().trim()
            if (n.isEmpty()) { name.error = "Isi nama acara"; false } else {
                events.put(JSONObject().put("id", System.currentTimeMillis().toString()).put("n", n))
                save(); fill(); true
            }
        }
    }

    private fun guestForm(g: JSONObject?) {
        val name = input("Nama tamu", g?.optString("n") ?: "")
        val address = input("Alamat", g?.optString("a") ?: "")
        val money = input("Nominal (angka saja)", g?.optLong("m")?.toString() ?: "")
        money.inputType = InputType.TYPE_CLASS_NUMBER
        form(if (g == null) "Tambah tamu" else "Ubah tamu", listOf(name, address, money)) {
            val n = name.text.toString().trim()
            val raw = money.text.toString()
            val m = if (raw.isEmpty()) 0L else raw.toLongOrNull()
            if (n.isEmpty()) { name.error = "Isi nama tamu"; false }
            else if (m == null) { money.error = "Angka tidak valid"; false }
            else {
                val target = g ?: JSONObject().put("id", System.currentTimeMillis().toString())
                    .put("e", current).also { guests.put(it) }
                target.put("n", n).put("a", address.text.toString().trim()).put("m", m)
                save(); fill(); true
            }
        }
    }
}
